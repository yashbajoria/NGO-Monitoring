<?php
    $to='teamlazarusnits@gmail.com';
    $subject='Acknowledgement Of Submission';
    $header='From Government Of India';
    $message='Your application has been recieved. We look forward to a transparent, fast and efficient process. Jai Hind';
    $to1='bajoriayash1@gmail.com';
    if(mail($to, $subject, $message, $header)){
        echo '1';
    }
    else{
        echo '0';
    }
?>
