<?php
	//Jai Ma Kali...........................................
	//Establishing connection...............................
	$dbName='';
	$userId='id8306447_warrioramrit';
	$loginPassword='theloyalassasin';
	$hostName='localhost';
	
	if(isset($_POST['userid']) && isset($_POST['fordays']) && isset($_POST['type'])){
		//initilizing...........
		$id=$_POST['userid'];
		$fordays=$_POST['fordays'];
		$type=$_POST['type'];
		
		//Getting the date and time*********88
		date_default_timezone_set('Asia/Kolkata'); // CDT

		$info = getdate();
		$date = $info['mday'];
		$month = $info['mon'];
		$year = $info['year'];
		$hour = $info['hours'];
		$min = $info['minutes'];
		$sec = $info['seconds'];
		
		$entdate=$date."/".$month."/".$year;
		
		//$current_date = "$date/$month/$year == $hour:$min:$sec";
		
		$ThatTime ="10:0:30";
			if (time() <= strtotime($ThatTime)) {
				//echo time();
			}
		
		//echo $date."/".$month."/".$year;
		//echo $hour."/".$min."/".$sec;
		//Got the date*********
		
		
		//Initilizing complete........
		if($login_con=mysqli_connect($hostName,$userId,$loginPassword,$dbName)){
			if(!empty($_POST['userid']) && !empty($_POST['fordays']) && !empty($_POST['type'])){
					$query_insert="INSERT INTO leaverecords(userid,date,fordays,type) VALUES(".$id.",'".$entdate."',".$fordays.",'".$type."')";
					if($table_entry_variable=mysqli_query($login_con,$query_insert)){
							echo '1';//1 means that record is Entered!!!!!!
					}
					else{
						echo '00';//00 means that record is not Entered due to entry query!!!!!
					}
			}
			else{
				echo '-1';//-1 means all fields are not filled!!!!
			}
		}
		else{
			echo '404';//Error 404 means connection not established!!!!
		}
	}
	//Connection Established................................
?>
<form action="insertIntoLeaveRecords.php" method="POST">
	<input type="Text" name="userid"/>
	<input type="Text" name="fordays"/>
	<input type="Text" name="type"/>
	<input type="submit" name="submit"/>
</form>
