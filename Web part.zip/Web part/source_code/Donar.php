<?php

    //Jai Ma Kali...........................................
	//Establishing connection...............................
	$dbName='id8306447_klal';
	$userId='id8306447_warrioramrit';
	$loginPassword='theloyalassasin';
	$hostName='localhost';
	
	if(isset($_POST['donarDetails'])){
		//initilizing...........
		$fname=$_POST['name'];
		$field=$_POST['field'];
		$prof=$_POST['prof'];
		
		$contact=$_POST['contact'];
		$amt=$_POST['amt'];
		
	
		
		
		//Initilizing complete........
		if($login_con=mysqli_connect($hostName,$userId,$loginPassword,$dbName)){
			if(!empty($_POST['name']) && !empty($_POST['field']) && !empty($_POST['prof']) && !empty($_POST['contact']) && !empty($_POST['amt'])){
					$query_insert="INSERT INTO NgoDonar(name,Profession,field,contact,amount) VALUES('".$fname."','".$prof."','".$field."','".$contact."','".$amt."')";
					if($table_entry_variable=mysqli_query($login_con,$query_insert)){
								echo '<script>alert("Your data has been recorded, We appriciate your kind gesture.")</script>';//1 means that record is Entered!!!!!!
					}
					else{
							echo '<script>alert("Unable to process the query")</script>';//00 means that record is not Entered due to entry query!!!!!
					}
			}
			else{
					echo '<script>alert("All fields are mandatory!")</script>';//-1 means all fields are not filled!!!!
			}
		}
		else{
				echo '<script>alert("Connection error, try later!")</script>';//Error 404 means connection not established!!!!
		}
	}
	//Connection Established................................

?>

<!DOCTYPE html>

<html>

    
    <head>
        <title>Donate</title>
    </head>
    
    <style>
    
    *{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Montserrat', sans-serif;
}
body{
  background: #2133bf;
  padding: 0 10px;
}
.wrapper{
  max-width: 600px;
  width: 100%;
  background: #fff;
  margin: 50px auto;
  box-shadow: 2px 2px 4px rgba(0,0,0,0.125);
  padding: 30px;
}

.wrapper .title{
  font-size: 20px;
  font-weight: 700;
  margin-bottom: 25px;
  color: #fec107;
  /* text-transform: uppercase; */
  text-align: center;
}

.wrapper .form{
  width: 100%;
}

.wrapper .form .inputfield{
  margin-bottom: 30px;
  display: flex;
  align-items: center;
}

.wrapper .form .inputfield label{
   width: 200px;
   color: #757575;
   margin-right: 10px;
  font-size: 14px;
}

.wrapper .form .inputfield .input,
.wrapper .form .inputfield .textarea{
  width: 100%;
  outline: none;
  border: 1px solid #d5dbd9;
  font-size: 15px;
  padding: 8px 10px;
  border-radius: 3px;
  transition: all 0.3s ease;
}

.wrapper .form .inputfield .textarea{
  width: 100%;
  height: 125px;
  resize: none;
}

.wrapper .form .inputfield .custom_select{
  position: relative;
  width: 100%;
  height: 37px;
}

.wrapper .form .inputfield .custom_select:before{
  content: "";
  position: absolute;
  top: 12px;
  right: 10px;
  border: 8px solid;
  border-color: #d5dbd9 transparent transparent transparent;
  pointer-events: none;
}

.wrapper .form .inputfield .custom_select select{
  -webkit-appearance: none;
  -moz-appearance:   none;
  appearance:        none;
  outline: none;
  width: 100%;
  height: 100%;
  border: 0px;
  padding: 8px 10px;
  font-size: 15px;
  border: 1px solid #d5dbd9;
  border-radius: 3px;
}


.wrapper .form .inputfield .input:focus,
.wrapper .form .inputfield .textarea:focus,
.wrapper .form .inputfield .custom_select select:focus{
  border: 1px solid #fec107;
}

.wrapper .form .inputfield p{
   font-size: 14px;
   color: #757575;
}
.wrapper .form .inputfield .check{
  width: 15px;
  height: 15px;
  position: relative;
  display: block;
  cursor: pointer;
}
.wrapper .form .inputfield .check input[type="checkbox"]{
  position: absolute;
  top: 0;
  left: 0;
  opacity: 0;
}
.wrapper .form .inputfield .check .checkmark{
  width: 15px;
  height: 15px;
  border: 1px solid #fec107;
  display: block;
  position: relative;
}
.wrapper .form .inputfield .check .checkmark:before{
  content: "";
  position: absolute;
  top: 1px;
  left: 2px;
  width: 5px;
  height: 2px;
  border: 2px solid;
  border-color: transparent transparent #fff #fff;
  transform: rotate(-45deg);
  display: none;
}
.wrapper .form .inputfield .check input[type="checkbox"]:checked ~ .checkmark{
  background: #fec107;
}

.wrapper .form .inputfield .check input[type="checkbox"]:checked ~ .checkmark:before{
  display: block;
}

.wrapper .form .inputfield .btn{
  width: 100%;
   padding: 8px 10px;
  font-size: 15px; 
  border: 0px;
  background:  #fec107;
  color: #fff;
  cursor: pointer;
  border-radius: 3px;
  outline: none;
}

.wrapper .form .inputfield .btn:hover{
  background: #ffd658;
}

.wrapper .form .inputfield:last-child{
  margin-bottom: 0;
}

@media (max-width:420px) {
  .wrapper .form .inputfield{
    flex-direction: column;
    align-items: flex-start;
  }
  .wrapper .form .inputfield label{
    margin-bottom: 5px;
  }
  .wrapper .form .inputfield.terms{
    flex-direction: row;
  }
}
    
    </style>

    <body>
    
      <div class="wrapper">
        <div class="title">
         Fill out the below details
        </div>
        <div class="form">
        <form action="Donar.php" method="POST">
           <div class="inputfield">
              <label>Full Name</label>
              <input type="text" name="name">
           </div>  
          <div class="inputfield">
              <label>Profession</label>
              <input type="text" name="prof">
           </div> 
           
            <div class="inputfield">
              <label>Which Field you are interested to fund</label>
              <input type="text" name="field">
           </div> 
          <div class="inputfield">
              <label>Phone Number</label>
              <input type="text" name="contact">
           </div> 
           <div class="inputfield">
              <label>Amount</label>
              <input type="text" name="amt">
           </div>
          <div class="inputfield">
            <input type="submit" value="Register" class="btn" name="donarDetails">
          </div>
          </form>
        </div>
    </div>
    
    </body>



</html>