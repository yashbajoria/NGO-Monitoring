<?php
	require "fpdf181/fpdf.php";
    $to='';


	$db=new PDO('mysql:host=localhost;dbname=id8306447_klal', 'id8306447_warrioramrit', 'theloyalassasin');
	
	class myPDF extends FPDF{
		function header(){
			$this->Image('logo3.png', 10, 6);
			$this->SetFont('Arial', 'B', 24);
			$this->Cell(276, 8, 'Grant Application', 0, 0, 'C');
			$this->Ln();
			$this->SetFont('Times', '', 12);
			$this->Cell(276, 15, '-Government Of India', 0, 0, 'C');
			$this->Ln();
			$this->Cell(276, 8, 'This application is just an acknoledgement and does not gurantee approval.', 0, 0, 'C');
			$this->Ln(20);
		}
		function footer(){
			$this->SetY(-15);
			$this->SetFont('Arial', '', 12);
			$this->Cell(276, 15, 'Page- '.$this->PageNo().'/{nb}', 0, 0, 'C');
		}
		function headerTable(){
			$this->SetFont('Times', 'B', 18);
			$this->Cell(30, 10, 'ID', 1, 0, 'C');
			$this->Cell(45, 10, 'NGO', 1, 0, 'C');
			$this->Cell(45, 10, 'Owner', 1, 0, 'C');
			$this->Cell(25, 10, 'Reports', 1, 0, 'C');
			$this->Cell(65, 10, 'Address', 1, 0, 'C');
			$this->Cell(65, 10, 'E-Mail', 1, 0, 'C');
			$this->Ln();
		}
		function viewTable(){
		    $id=$randnum = rand(11111111,99999999);
		    $ngo=$_POST['ngo'];
		    $owner=$_POST['owner'];
		    $annual=$_POST['annual'];
		    $add=$_POST['add'];
		    $mail=$_POST['mail'];
			$this->SetFont('Times', 'B', 14);
			$this->Cell(30, 10, $id, 1, 0, 'C');
			$this->Cell(45, 10, $ngo, 1, 0, 'C');
			$this->Cell(45, 10, $owner, 1, 0, 'C');
			$this->Cell(25, 10, $annual, 1, 0, 'C');
			$this->Cell(65, 10, $add, 1, 0, 'C');
			$this->Cell(65, 10, $mail, 1, 0, 'C');
			$this->Ln();
			$this->Cell(210, 10, 'Recieved successfully.', 1, 0, 'C');
			$this->Cell(65, 10, 'System Generated.', 1, 0, 'C');
			$to=$mail;
			
			$db=new PDO('mysql:host=localhost;dbname=id8306447_klal', 'id8306447_warrioramrit', 'theloyalassasin');
			$stmt=$db->query("INSERT INTO NgoGrantFund(grantid,name,owner,reports,address,mail,status) VALUES($id,'".$ngo."','".$owner."',".$annual.",'".$add."','".$mail."',1)");
		}
	}
	
	if(isset($_POST['grantpdf'])){
		$pdf=new myPDF();
		$pdf->AliasNbPages();
		$pdf->AddPage('L', 'A4', 0);
		$pdf->headerTable();
		$pdf->viewTable();
		//
		
		
		
		$pdf->Output();
	}
?>