<?php
	require "fpdf181/fpdf.php";



//	$db=new PDO('mysql:host=localhost;dbname=id8306447_klal', 'id8306447_warrioramrit', 'theloyalassasin');
	
	class myPDF extends FPDF{
		function header(){
			$this->Image('logo3.png', 10, 6);
			$this->SetFont('Arial', 'B', 24);
			$this->Cell(276, 8, 'Permission Status', 0, 0, 'C');
			$this->Ln();
			$this->SetFont('Times', '', 12);
			$this->Cell(276, 15, '-For more information contact your District Magistrate.', 0, 0, 'C');
			$this->Ln();
			$this->Cell(276, 8, 'This application is just an acknoledgement and does not gurantee approval.', 0, 0, 'C');
			$this->Ln(20);
		}
		function footer(){
			$this->SetY(-15);
			$this->SetFont('Arial', '', 12);
			$this->Cell(276, 15, 'Page- '.$this->PageNo().'/{nb}', 0, 0, 'C');
		}
		function headerTable(){
			
		}
		function viewTable(){
		
			$this->SetFont('Times', 'B', 18);
			$this->Cell(30, 10, 'ID', 1, 0, 'C');
			$this->Cell(45, 10, 'name', 1, 0, 'C');
			$this->Cell(45, 10, 'For', 1, 0, 'C');
			$this->Cell(25, 10, 'Date', 1, 0, 'C');
			$this->Cell(45, 10, 'Location', 1, 0, 'C');
			$this->Cell(60, 10, 'E-Mail', 1, 0, 'C');
			$this->Cell(25, 10, 'Status', 1, 0, 'C');
			$this->Ln();
		
		
		    $db=new PDO('mysql:host=localhost;dbname=id8306447_klal', 'id8306447_warrioramrit', 'theloyalassasin');
		    $id=$_POST['permstatid'];
			if($stmt=$db->query("SELECT * FROM NgoPermission WHERE permissionId LIKE ".$id)){
				while($data=$stmt->fetch(PDO::FETCH_OBJ)){
					$this->SetFont('Times', 'B', 14);
					$this->Cell(30, 10, $id, 1, 0, 'C');
					$this->Cell(45, 10, $data->name, 1, 0, 'C');
					$this->Cell(45, 10, $data->reason, 1, 0, 'C');
					$this->Cell(25, 10, $data->date, 1, 0, 'C');
					$this->Cell(45, 10, $data->location, 1, 0, 'C');
					$this->Cell(60, 10, $data->mail, 1, 0, 'C');
					$this->Cell(25, 10, $data->status, 1, 0, 'C');
					$this->Ln();
					$this->Cell(215, 10, 'Recieved successfully.', 1, 0, 'C');
					$this->Cell(60, 10, 'System Generated.', 1, 0, 'C');  
					$this->Ln();
				}
				$this->Ln();
				$this->Ln();
				$this->Cell(275, 10, 'Key To Abbriviations', 1, 0, 'C');
				$this->Ln();
				$this->Cell(275, 10, '1 - Application Filed', 1, 0, 'L');
				$this->Ln();
				$this->Cell(275, 10, '2 - Report Verified', 1, 0, 'L');
				$this->Ln();
				$this->Cell(275, 10, '3 - In-Person Verified', 1, 0, 'L');
				$this->Ln();
				$this->Cell(275, 10, '4 - Awaiting official assent', 1, 0, 'L');
				$this->Ln();
				$this->Cell(275, 10, '5 - Accepted', 1, 0, 'L');
				$this->Ln();
				$this->Cell(275, 10, '-1 - Rejected', 1, 0, 'L');
			}
			else{
			    $this->Ln();
				$this->Cell(275, 10, 'Invalid ID, try again.', 1, 0, 'C');
			}
		}
	}
	
	if(isset($_POST['permstatsubmit'])){
		$pdf=new myPDF();
		$pdf->AliasNbPages();
		$pdf->AddPage('L', 'A4', 0);
		$pdf->headerTable();
		$pdf->viewTable();
		$pdf->Output();
	}
?>