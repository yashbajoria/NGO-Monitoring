<?php
	require "fpdf181/fpdf.php";



	$db=new PDO('mysql:host=localhost;dbname=id8306447_klal', 'id8306447_warrioramrit', 'theloyalassasin');
	
	class myPDF extends FPDF{
		function header(){
			$this->Image('logo3.png', 10, 6);
			$this->SetFont('Arial', 'B', 24);
			$this->Cell(276, 8, 'Permission Application', 0, 0, 'C');
			$this->Ln();
			$this->SetFont('Times', '', 12);
			$this->Cell(276, 15, '-Government Of India', 0, 0, 'C');
			$this->Ln();
			$this->Cell(276, 8, 'This application is just an acknoledgement and does not gurantee approval.', 0, 0, 'C');
			$this->Ln(20);
		}
		function footer(){
			$this->SetY(-15);
			$this->SetFont('Arial', '', 12);
			$this->Cell(276, 15, 'Page- '.$this->PageNo().'/{nb}', 0, 0, 'C');
		}
		function headerTable(){
			$this->SetFont('Times', 'B', 18);
			$this->Cell(30, 10, 'ID', 1, 0, 'C');
			$this->Cell(45, 10, 'NGO', 1, 0, 'C');
			$this->Cell(25, 10, 'Crowd', 1, 0, 'C');
			$this->Cell(45, 10, 'For', 1, 0, 'C');
			$this->Cell(25, 10, 'Date', 1, 0, 'C');
			$this->Cell(45, 10, 'Location', 1, 0, 'C');
			$this->Cell(60, 10, 'E-Mail', 1, 0, 'C');
			$this->Ln();
		}
		function viewTable(){
		    $id=$randnum = rand(11111111,99999999);
		    $ngo=$_POST['ngo'];
		    $crd=$_POST['crd'];
		    $pf=$_POST['pf'];
		    $date=$_POST['date'];
		    $loc=$_POST['loc'];
		    $mail=$_POST['mail'];
			$this->SetFont('Times', 'B', 14);
			$this->Cell(30, 10, $id, 1, 0, 'C');
			$this->Cell(45, 10, $ngo, 1, 0, 'C');
			$this->Cell(25, 10, $crd, 1, 0, 'C');
			$this->Cell(45, 10, $pf, 1, 0, 'C');
			$this->Cell(25, 10, $date, 1, 0, 'C');
			$this->Cell(45, 10, $loc, 1, 0, 'C');
			$this->Cell(60, 10, $mail, 1, 0, 'C');
			$this->Ln();
			$this->Cell(215, 10, 'Recieved successfully.', 1, 0, 'C');
			$this->Cell(60, 10, 'System Generated.', 1, 0, 'C');
			
			$db=new PDO('mysql:host=localhost;dbname=id8306447_klal', 'id8306447_warrioramrit', 'theloyalassasin');
			$stmt=$db->query("INSERT INTO NgoPermission(permissionId,name,crowd,reason,date,location,mail,status) VALUES(".$id.",'".$ngo."',".$crd.",'".$pf."','".$date."','".$loc."','".$loc."',1)");
		}
	}
	
	if(isset($_POST['permissionpdf'])){
		$pdf=new myPDF();
		$pdf->AliasNbPages();
		$pdf->AddPage('L', 'A4', 0);
		$pdf->headerTable();
		$pdf->viewTable();
		$pdf->Output();
	}
?>