<!DOCTYPE html>



<?php



//Uploading the file..................

if(isset($_POST['fileupload'])){
    
    $filename=$_FILES['filename']['name'];
    $filetype=$_FILES['filename']['type'];
    $filesize=$_FILES['filename']['size'];
    $filetemploc=$_FILES['filename']['tmp_name'];
    
    $base= basename($filename);
    $extension= substr($base, strlen($base)-4, strlen($base));
    
    $allow=array(".pdf");
    
    if(in_array($extension, $allow)){
        
        $filestore=getcwd().DIRECTORY_SEPARATOR.$filename;
        if(move_uploaded_file($filetemploc, $filestore)){
            
            
            //Sending the mail...
            $to=$_POST['eid'];
            //echo $to;
            $subject='Acknowledgement Of Submission Of Report';
            $header='From Government Of India';
            $message='Your Report has been recieved. We look forward to a transparent, fast and efficient process. Jai Hind';
            
            
            
            if(mail($to, $subject, $message, $header)){
                echo '<script>alert("Uploading Successfull!, Recipt sent to your registered mail id!")</script>';
            }
            else{
                echo '<script>alert("Uploading Successfull!, Recipt NOT SENT!")</script>';
            }
            
            
        }
        else{
            //Not a .pdf file..............
            echo '<script>alert("Uploading Failed!")</script>';
        }
        
    }
    else{
        echo '<script>alert("File format not acceptable, upload a .pdf file.")</script>';
    }
}



?>





<html lang="en">

  <head>
    
    <!-- Meta Tag -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>WEB</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon/favicon.png">
    
    <!-- All CSS Plugins -->
    <link rel="stylesheet" type="text/css" href="css/plugin.css">
    
    <!-- Main CSS Stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <!-- Google Web Fonts  -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700">
    <link href="https://fonts.googleapis.com/css?family=Abril+Fatface" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css?family=Cabin" rel="stylesheet">
   <link href="bootstrap-3.3.7-dist/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css">

 </head>

  <body>
    
    
	
	

    
    
    <!-- Home & Menu Section Start -->
    <header id="home" class="home-section">
        
        <div class="header-top-area">
            <div class="container">
                <div class="row">
                
                    <div class="col-sm-3">
                        <div class="logo">
                            <a href="index.html"></a>
                        </div>
                    </div>
                    
                    <div class="col-sm-8">
                        <div class="navigation-menu">
                            <div class="navbar">
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                        <span class="sr-only"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>
                                <div class="navbar-collapse collapse">
                                    <ul class="nav navbar-nav navbar-right">
                                        <li class="active"><a class="smoth-scroll" href="#home">Home <div class="ripple-wrapper"></div></a>
                                        </li>
                                        
                                        <li><a class="smoth-scroll" href="#funding">Funding</a>
                                        </li>
                                        <li><a class="smoth-scroll" href="#funding">Permission</a>
                                        </li>
                                        <li><a class="smoth-scroll" href="#quality">Quality Report</a>
                                        </li>
                                        <li><a class="smoth-scroll" href="#contact">Contact</a>
                                        </li>
                                        <li><a class="smoth-scroll" href="/Lannisters/source_code" onclick="<?php
                                            session_start();
                                            header("http://monoclinous-beaches.000webhostapp.com/Lannisters/source_code/index.php"); 
                                            
                                        ?>">Logout</a>
                                        </li>
                                       
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    </div>
                </div>
            </div>
        </div>
        
        <div class="home-section-background1" data-stellar-background-ratio="0.6">
            <div class="display-table">
                <div class="display-table-cell">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <div class="header-text">
                                  <p></p>
                                    <h2><span class="typing3"></span></h2>
                                    <h5><span class="typing4"></span></h5>
                                    
                                    <div class="margin-top-10">
                          <a class="button button-style button-style-icon fa fa-long-arrow-right smoth-scroll" href="Donations.php">Donations provided</a>
                                  </div>
                                 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </header>
    <!-- Home & Menu Section End-->
    
     
    
    
    
    
    <section id="funding" class="services-section padding-top-30">
        <div id="fh5co-schedule-section">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2">
            <div class="section-title">
              <h2>Funds and Permit</h2>
              
            </div>
          </div>
        </div>
        <div class="row animate-box">
          <div class="row text-center">

            <div class="col-md-12 schedule-container">
                <div class="col-md-6 col-sm-6" >
                  <div class="program program-schedule" >
                    
                    <h3>FUNDING</h3><br>
                    <p>The process for application is as follows:<br>
1.  To get an insight of the estimated funds that your NGO might receive, you may click on ‘Expected Funding’ Button, fill the form and click on Submit button. <br>
2.  After getting a proposed estimation of the fund that you might receive, if impressed, you may proceed to click on ‘Application Form’ button, fill the form and click on Submit button.</p>
<br>
                   <button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal">Application Form</button>


                   <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content ">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Fill the Form</h4>
          
        </div>
        <div class="modal-body mm text-center">
                    
            
              <form action="grantApplicationPDF.php" method="POST">
Name of NGO:<br>
<input type="text" name="ngo">
<br>
Owner Name:<br>
<input type="text" name="owner">
<br>
Annual Report Count:<br>
<input type="text" name="annual">
<br>
Address of NGO:<br>
<input type="text" name="add">
<br>
Email ID:<br>
<input type="text" name="mail">
<br>
<br>
<input type="submit" name="grantpdf">
</form>

                                        
                </div>
           
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
            <button type="button" class="btn btn-default"><a href="https://hacks-ml-api.herokuapp.com/" style="text-decoration: none" target="_blank">Expected funding</a></button>
                  </div>
                </div>

                 <div class="col-md-6 col-sm-6" >
                  <div class="program program-schedule" >
                    
                    <h3>PERMISSION</h3><br>
                    <p>Go through the guidelines listed below, for permission granting. Then click on ‘Permission Form’ button, fill the form and click submit. <br> 
1. Gatherings must not involve more than 500 people. If expected crowd might exceed the limit, a proper permission must be taken from the State authority in person. <br>
2. The exact method of expression (rally, speech, etc.) need to be specified in the form.
</p>
                    
                   <button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal1">Permission Form</button>


                   <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content ">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Fill the Form</h4>
          
        </div>
        <div class="modal-body mm text-center">
                    
            
              <form action="generatePermissionPDF.php" method="POST">
Name of NGO:<br>
<input type="text" name="ngo">
<br>
Total Crowd:<br>
<input type="text" name="crd">
<br>
Permission for (example rally,speech,etc.):<br>
<input type="text" name="pf">
<br>
Date:(dd/mm/yyyy)<br>
<input type="text" name="date">
<br>
Location required:<br>
<input type="text" name="loc">
<br>
Email ID:<br>
<input type="text" name="mail">
<br>
<br>
<input type="submit" name="permissionpdf">
</form>

                                        
                </div>
           
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  <button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal3">Permission Status</button>


                   <div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content ">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Details</h4>
          
        </div>
        <div class="modal-body mm text-center">
                    <p>Enter your permit id (which you received through the pdf on submitting the permission form) below, to know about the current status of the verification and grant of the permission you applied for.</p>
            
              <form action="generateStatusPDF.php" method="POST">
Permit ID:<br>
<input type="text" name="permstatid">
<br>
<br>
<input type="submit" name="permstatsubmit">
</form>

                                        
                </div>
           
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    


    <section id="quality" class="portfolio section-space-padding fh5co-lightgray-section">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title">
                        <h2>Quality Report</h2>
                        
                    </div>
                </div>
            </div>
            <div class="portfolio-inner">
                <div class="row">
                <p>Each of the registered NGOs need to file their annual quality report which must include the below mentioned information.<br>
1. Objectives set by the NGO at the beginning of the fiscal year and how much of it has been achieved.<br>
2. Audit report of the last fiscal year.<br>
3. Growth in terms of registered members, trained staff and capital investments.<br>
4. An affidavit declaring that all the information provided above are true.<br>
The uploaded report shall be an important factor in determining the feasibility of the funds/grants and permissions. This document is intended to bring about transparency in governance of NGOs. It will also send a pdf receipt as an acknowledgement to your registered email id.</p>
                
                    
                    
                    
                    
                    <form action="main.php" method="POST" enctype="multipart/form-data">
                      <div class="margin-top-10">
                        <div class="col-md-12 text-center">
 <input class="button button-style button-style-icon fa fa-long-arrow-right smoth-scroll" type="file" id="myFile" type="file" name="filename" align="text-center">
 <h4>Email ID:</h4>
<input type="text" name="eid"><br><br>
  <input type="submit" align="centre" name="fileupload">
</div>
</div>
</form>
                    
                </div>
            </div>
        </div>
     
     </section>
    
   
       
       
       
    <!-- Contact Start -->
    <section id="contact" class="contact-us padding-top-30">
       <div class="container">
          <div class="row">
                <div class="col-sm-12">
                    <div class="section-title">
                        <h2>Contact Us</h2>
                        <p>For any queries, reach us out at</p>
                    </div>
                </div>
            </div>
            
            
           <div class="text-center margin-top-10 margin-bottom-50">
            <div class="row">
            
               <div class="col-md-4 col-sm-4">
                <div class="contact-us-detail">  
                 <i class="fa fa-mobile color-6"></i>
                  <p><a>+91-9101244646</a><br>
                      <a>+91-8876506186</a>
                    </p>
                 </div>
                </div>
               
               <div class="col-md-4 col-sm-4">
                <div class="contact-us-detail">
                 <i class="fa fa-mail-reply color-5"></i>
                  <p><a>team.ngomonitoring@gmail.com</a></p>
                 </div>
                </div>
                 
               <div class="col-md-4 col-sm-4">
                <div class="contact-us-detail">
                 <i class="fa fa-clock-o color-3"></i>
                  <p>Mon - Sat | 09:00 – 20:00</p>
                 </div>
                </div>
              
               </div>
              </div>
         
       </div>
       
      <div class="margin-top-40"> 
       <ul class="social-icon">
         <li><a href="https://www.facebook.com/NITSHacks/?epa=SEARCH_BOX" target="_blank" class="facebook"><i class="fa fa-facebook"></i></a></li>
           <li><a href="https://twitter.com/narendramodi" target="_blank" class="twitter"><i class="fa fa-twitter"></i></a></li>
       </ul>
      </div>
       
     </section>
     <!-- Contact End -->
       
        
        
            <!-- Back to Top Start -->
    <a href="#" class="scroll-to-top"><i class="fa fa-angle-up"></i></a
    <!-- Back to Top End -->
    
    
    
    
    
    <!-- All Javascript Plugins  -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/plugin.js"></script>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyC0HAKwKinpoFKNGUwRBgkrKhF-sIqFUNA"></script>
    
    <!-- Main Javascript File  -->
    <script type="text/javascript" src="js/scripts.js"></script>
  
  
  </body>
 </html>






