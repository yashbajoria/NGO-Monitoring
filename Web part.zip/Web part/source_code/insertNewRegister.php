<?php
	//Jai Ma Kali...........................................
	//Establishing connection...............................
	$dbName='';
	$userId='id8306447_warrioramrit';
	$loginPassword='theloyalassasin';
	$hostName='localhost';
	
	if(isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['worth']) && isset($_POST['followers']) && isset($_POST['reach']) && isset($_POST['rating']) && isset($_POST['staff']) && isset($_POST['international']) && isset($_POST['national']) && isset($_POST['certify']) && isset($_POST['web']) && isset($_POST['state']) && isset($_POST['work']) && isset($_POST['years']) && isset($_POST['ireach']) && isset($_POST['grants']) && isset($_POST['report'])){
		//initilizing...........
		$fname=$_POST['firstname'];
		$pass=$_POST['lastname'];
		$worth=$_POST['worth'];
		
		$follow=$_POST['followers'];
		$reach=$_POST['reach'];
		$rate=$_POST['rating'];
		
		$staff=$_POST['staff'];
		$international=$_POST['international'];
		$national=$_POST['national'];
		
		$certify=$_POST['certify'];
		$web=$_POST['web'];
		$grants=$_POST['grants'];
		
		$report=$_POST['report'];
		$state=$_POST['state'];
		$work=$_POST['work'];
		$years=$_POST['years'];
		$ireach=$_POST['ireach'];
	
		
		
		//Initilizing complete........
		if($login_con=mysqli_connect($hostName,$userId,$loginPassword,$dbName)){
			if(!empty($_POST['firstname']) && !empty($_POST['lastname']) && !empty($_POST['worth']) && !empty($_POST['followers']) && !empty($_POST['reach']) && !empty($_POST['rating']) && !empty($_POST['staff']) && !empty($_POST['international']) && !empty($_POST['national']) && !empty($_POST['certify']) && !empty($_POST['web']) && !empty($_POST['grants']) && !empty($_POST['report']) && !empty($_POST['state']) && !empty($_POST['work']) && !empty($_POST['years']) && !empty($_POST['ireach'])){
					$query_insert="INSERT INTO NgoRegister(userid,password,worth,followers,reach,mediarating,staff,internationalawards,nationalawards,certifications,website,statereach,field,activeyears,internationalreach,annualreport,grants) VALUES('".$fname."','".$pass."',".$worth.",".$follow.",".$reach.",".$rate.",".$staff.",".$international.",".$national.",".$certify.",'".$web."',".$state.",'".$work."',".$years.",".$ireach.",".$report.",".$grants.")";
					if($table_entry_variable=mysqli_query($login_con,$query_insert)){
								echo '<script>alert("You successfully registered.")</script>';//1 means that record is Entered!!!!!!
					}
					else{
							echo '<script>alert("Unable to process the query")</script>';//00 means that record is not Entered due to entry query!!!!!
					}
			}
			else{
					echo '<script>alert("All fields are mandatory!")</script>';//-1 means all fields are not filled!!!!
			}
		}
		else{
				echo '<script>alert("Connection error, try later!")</script>';//Error 404 means connection not established!!!!
		}
	}
	//Connection Established................................
?>
