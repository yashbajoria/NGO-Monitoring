<!DOCTYPE html>

<?php

    //Jai Ma Kali...........................................
	//Establishing connection...............................
	$dbName='id8306447_klal';
	$userId='id8306447_warrioramrit';
	$loginPassword='theloyalassasin';
	$hostName='localhost';
	
	if(isset($_POST['donarDetails'])){
		//initilizing...........
		$fname=$_POST['name'];
		$field=$_POST['field'];
		$prof=$_POST['prof'];
		
		$contact=$_POST['contact'];
		$amt=$_POST['amt'];
		
	
		
		
		//Initilizing complete........
		if($login_con=mysqli_connect($hostName,$userId,$loginPassword,$dbName)){
			if(!empty($_POST['name']) && !empty($_POST['field']) && !empty($_POST['prof']) && !empty($_POST['contact']) && !empty($_POST['amt'])){
					$query_insert="INSERT INTO NgoDonar(name,Profession,field,contact,amount) VALUES('".$fname."','".$prof."','".$field."','".$contact."','".$amt."')";
					if($table_entry_variable=mysqli_query($login_con,$query_insert)){
								echo '<script>alert("Your data has been recorded, We appriciate your kind gesture.")</script>';//1 means that record is Entered!!!!!!
					}
					else{
							echo '<script>alert("Unable to process the query")</script>';//00 means that record is not Entered due to entry query!!!!!
					}
			}
			else{
					echo '<script>alert("All fields are mandatory!")</script>';//-1 means all fields are not filled!!!!
			}
		}
		else{
				echo '<script>alert("Connection error, try later!")</script>';//Error 404 means connection not established!!!!
		}
	}
	//Connection Established................................

?>

<html>
<head>
    <title>WEB</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="css/icomoon.css">
</head>
<body>
    <form action="rough.php" method="POST">
Name:<br>
<input type="text" name="name">
<br>
Profession:<br>
<input type="text" name="prof">
<br>
The field(s) of NGO (e.g. Women empowerment, child welfare, etc.), you are interested to donate for:<br>
<input type="text" name="field">
<br>
Contact No. through which an NGO may contact you:<br>
<input type="text" name="contact">
<br>
Exact donation amount in numbers:<br>
<input type="text" name="amt">
<br>
<br>
<input type="submit" name="donarDetails">
                              </form>

</body>
</html>