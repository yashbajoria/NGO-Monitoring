<?php
	require "fpdf181/fpdf.php";

	class myPDF extends FPDF{
		function header(){
			$this->Image('logo3.png', 10, 6);
			$this->SetFont('Arial', 'B', 24);
			$this->Cell(276, 8, 'List Of Potential Donars', 0, 0, 'C');
			$this->Ln();
			$this->SetFont('Times', '', 12);
			$this->Cell(276, 15, '-For more information contact your District Magistrate.', 0, 0, 'C');
			$this->Ln();
			$this->Cell(276, 8, 'This application is just an acknoledgement and does not gurantee donations.', 0, 0, 'C');
			$this->Ln(20);
		}
		function footer(){
			$this->SetY(-15);
			$this->SetFont('Arial', '', 12);
			$this->Cell(276, 15, 'Page- '.$this->PageNo().'/{nb}', 0, 0, 'C');
		}
		function headerTable(){
			
		}
		function viewTable(){
		
			$this->SetFont('Times', 'B', 18);
			$this->Cell(60, 10, 'Name', 1, 0, 'C');
			$this->Cell(60, 10, 'Profession', 1, 0, 'C');
			$this->Cell(60, 10, 'Intrested Field', 1, 0, 'C');
			$this->Cell(50, 10, 'Contact', 1, 0, 'C');
			$this->Cell(45, 10, 'Amount', 1, 0, 'C');
			$this->Ln();
		
		
		    $db=new PDO('mysql:host=localhost;dbname=id8306447_klal', 'id8306447_warrioramrit', 'theloyalassasin');
			if($stmt=$db->query("SELECT * FROM NgoDonar")){
				while($data=$stmt->fetch(PDO::FETCH_OBJ)){
					$this->SetFont('Times', 'B', 14);
					$this->Cell(60, 10, $data->name, 1, 0, 'C');
					$this->Cell(60, 10, $data->Profession, 1, 0, 'C');
					$this->Cell(60, 10, $data->field, 1, 0, 'C');
					$this->Cell(50, 10, $data->contact, 1, 0, 'C');
					$this->Cell(45, 10, $data->amount, 1, 0, 'C');
					$this->Ln();
				}
				$this->Ln();
				$this->Ln();
				$this->Cell(275, 10, 'List Complete', 1, 0, 'C');
				$this->Ln();
			}
			else{
			    $this->Ln();
				$this->Cell(275, 10, 'Invalid ID, try again.', 1, 0, 'C');
			}
		}
	}
	
		$pdf=new myPDF();
		$pdf->AliasNbPages();
		$pdf->AddPage('L', 'A4', 0);
		$pdf->headerTable();
		$pdf->viewTable();
		$pdf->Output();
?>