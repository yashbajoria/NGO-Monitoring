<!DOCTYPE html>
<?php
	//Jai Ma Kali...........................................
	//Establishing connection...............................
	//session_start();
	$dbName='id8306447_klal';
	$userId='id8306447_warrioramrit';
	$loginPassword='theloyalassasin';
	$hostName='localhost';
	
	
	
	//Code for login...........................................................................................
	
	
	
	if(isset($_POST['logfirstname']) && isset($_POST['loglastname'])){
		//initilizing...........
		$username=$_POST['logfirstname'];
		$password=$_POST['loglastname'];
		if($login_con=mysqli_connect($hostName,$userId,$loginPassword,$dbName)){
			if(!empty($_POST['logfirstname']) && !empty($_POST['loglastname'])){
				$query_check="SELECT * FROM NgoRegister WHERE userid LIKE '".$username."' AND password LIKE '".$password."'";
				if($foundRecordsArray=mysqli_fetch_assoc($table_login_variable=mysqli_query($login_con,$query_check))){
					echo '<script>alert("LogIn Successful!")</script>';//1 means that record is found!!!!!!
					echo "<script> location.href='main.php'; </script>";
                    exit;
				}
				else{
					echo '<script>alert("Wrong userid or password!")</script>';//0 means that record is not found!!!!!
				}
			}
			else{
				echo '<script>alert("All fields are mandatory!")</script>';//-1 means all fields are not filled!!!!
			}
		}
		else{
			echo '<script>alert("Unable to connect!")</script>';//Error 404 means connection not established!!!!
		}
	}
	//Connection Established................................
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//Code for register.......................................................................................
		if(isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['worth']) && isset($_POST['followers']) && isset($_POST['reach']) && isset($_POST['rating']) && isset($_POST['staff']) && isset($_POST['international']) && isset($_POST['national']) && isset($_POST['certify']) && isset($_POST['web']) && isset($_POST['state']) && isset($_POST['work']) && isset($_POST['years']) && isset($_POST['ireach']) && isset($_POST['grants']) && isset($_POST['report'])){
		//initilizing...........
		$fname=$_POST['firstname'];
		$pass=$_POST['lastname'];
		$worth=$_POST['worth'];
		
		$follow=$_POST['followers'];
		$reach=$_POST['reach'];
		$rate=$_POST['rating'];
		
		$staff=$_POST['staff'];
		$international=$_POST['international'];
		$national=$_POST['national'];
		
		$certify=$_POST['certify'];
		$web=$_POST['web'];
		$grants=$_POST['grants'];
		
		$report=$_POST['report'];
		$state=$_POST['state'];
		$work=$_POST['work'];
		$years=$_POST['years'];
		$ireach=$_POST['ireach'];
	
	    $id=$randnum = rand(11111111,99999999);
		//echo "<script type='text/javascript'>alert('{$id}');</script>";
		$mysqli = new mysqli($hostName,$userId,$loginPassword,$dbName);
		//Initilizing complete........
		if($login_con=mysqli_connect($hostName,$userId,$loginPassword,$dbName)){
			if(!empty($_POST['firstname']) && !empty($_POST['lastname']) && !empty($_POST['worth']) && !empty($_POST['followers']) && !empty($_POST['reach']) && !empty($_POST['rating']) && !empty($_POST['staff']) && !empty($_POST['international']) && !empty($_POST['national']) && !empty($_POST['certify']) && !empty($_POST['web']) && !empty($_POST['grants']) && !empty($_POST['report']) && !empty($_POST['state']) && !empty($_POST['work']) && !empty($_POST['years']) && !empty($_POST['ireach'])){
					$query_insert="INSERT INTO NgoRegister(registrationid,userid,password,worth,followers,reach,mediarating,staff,internationalawards,nationalawards,certifications,website,statereach,field,activeyears,internationalreach,annualreport,grants) VALUES('".$id."','".$fname."','".$pass."','".$worth."','".$follow."','".$reach."','".$rate."','".$staff."','".$international."','".$national."','".$certify."','".$web."','".$state."','".$work."','".$years."','".$ireach."','".$report."','".$grants."')";
					
					
					/*
					
					INSERT INTO NgoRegister(registrationid,userid,password,worth,followers,reach,mediarating,staff,internationalawards,nationalawards,certifications,website,statereach,field,activeyears,internationalreach,annualreport,grants) VALUES(\'".$id."\',\'".$fname."\',\'".$pass."\',\'".$worth."\',\'".$follow."\',\'".$reach."\',\'".$rate."\',\'".$staff."\',\'".$international."\',\'".$national."\',\'".$certify."\',\'".$web."\',\'".$state."\',\'".$work."\',\'".$years."\',\'".$ireach."\',\'".$report."\',\'".$grants."\')
					
					
					
					*/
					if($table_entry_variable=mysqli_query($login_con,$query_insert)){
								echo '<script>alert("You successfully registered.")</script>';//1 means that record is Entered!!!!!!
					}
					else{
					        /*echo "<script type='text/javascript'>alert('{$query_insert}{$fname}{$pass}{$worth}{$follow}{$reach}{$rate}{$staff}{$international}{$national}{$certify}{$web}{$state}{$work}{$years}{$ireach}{$report}{$grants}'.$mysqli -> error);</script>";*/
					        echo "<script type='text/javascript'>alert('{$query_insert}');</script>";
					      // echo $mysqli -> error;
							//echo '<script>alert("Unable to process the query")</script>';//00 means that record is not Entered due to entry query!!!!!
					}
			}
			else{
			         
					echo '<script>alert("All fields are mandatory!")</script>';//-1 means all fields are not filled!!!!
			}
		}
		else{
				echo '<script>alert("Connection error, try later!")</script>';//Error 404 means connection not established!!!!
		}
	}
	//Connection Established................................
?>


<html lang="en">

  <head>
    
     <!-- Meta Tag -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>WEB</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon/favicon.png">
    
    <!-- All CSS Plugins -->
    <link rel="stylesheet" type="text/css" href="css/plugin.css">
    
    <!-- Main CSS Stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <!-- Google Web Fonts  -->
   
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700">
    <link href="https://fonts.googleapis.com/css?family=Abril+Fatface" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css?family=Cabin" rel="stylesheet">
   <link href="bootstrap-3.3.7-dist/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css">
 </head>

  <body>
    
    
	
	<!-- Preloader Start -->
    <div id="preloader">
	  <div class="loader"></div>
    </div>
    <!-- Preloader End -->

    
    
    <!-- Home & Menu Section Start -->
    <header id="home" class="home-section">
        
        <div class="header-top-area">
            <div class="container">
                <div class="row">
                
                    <div class="col-sm-3">
                        
                    </div>
                    
                    <div class="col-sm-8">
                        <div class="navigation-menu">
                            <div class="navbar">
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                        <span class="sr-only"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>
                                <div class="navbar-collapse collapse">
                                    <ul class="nav navbar-nav navbar-right">
                                        <li class="active"><a class="smoth-scroll" href="#home">Home <div class="ripple-wrapper"></div></a>
                                        </li>
                                        <li><a class="smoth-scroll" href="#notification">Notification</a>
                                        </li>
                                        <li><a class="smoth-scroll" href="#services">Register</a>
                                        </li>
                                        <li><a class="smoth-scroll" href="#services">Login</a>
                                        </li>
                                        <li><a class="smoth-scroll" href="#contact">Contact</a>
                                        </li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1">
                        
                    </div>
                </div>
            </div>
        </div>
        
        <div class="home-section-background" data-stellar-background-ratio="0.6">
            <div class="display-table">
                <div class="display-table-cell">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <div class="header-text">
                                    <p></p>
                                    <h2><span class="typing"></span></h2>
                                    <h5><span class="typing2"></span></h5>
                                    
                                    <div class="margin-top-10">
                          <a class="button button-style button-style-icon fa fa-long-arrow-right smoth-scroll" href="Donar.php">Donate</a>
                                  </div>
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </header>
    <!-- Home & Menu Section End-->
    
    <!-- *******************************************************************************-->
    
    
    
    
    
    
    
    
    
    <section id="notification" class="testimonial-section section-space-padding padding-top-30 padding-bottom-40">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title">
                        <h2>Notification</h2>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="testimonial-carousel-list margin-top-20">

                    <div class="testimonial-word text-center">
                    
                        <h2>1.</h2><ul>
                          <li>An eligible functionary or beneficiary desirous of availing the benefits under the said Schemes offered through
NGOs is required to furnish proof of possession of Aadhaar or undergo Aadhaar authentication. 
</li></ul>
                    </div>
                
                    <div class="testimonial-word text-center">
                    
                        <h2>2.</h2>
                        <ul><li>As per regulation 12 of the Aadhaar (Enrolment and Update) Regulations, 2016, the concerned NGO incharge of
implementation of the Schemes under the Ministry, which requires an individual to furnish Aadhaar, is required to
facilitate Aadhaar enrolment for the functionaries or beneficiaries who are not yet enrolled for Aadhaar and in case
there is no Aadhaar enrolment centre located in the respective Block or Taluka or Tehsil, the Department of Social
Justice and Empowerment, Government of India, through its implementing NGOs and respective State Government or Union territory Administration where such NGOs are functioning is required to provide Aadhaar enrolment
facilities at convenient locations in coordination with the existing Registrars of UIDAI.</li></ul>
                    </div>

                    <div class="testimonial-word text-center">
                    
                        <h2>3.</h2>
                        <ul><li>All NGOs are hereby requested to update their Organisation PAN No as well as Aadhaar No & PAN No of their Board Members/Office Bearers in the NGO-DARPAN Portal of the NITI Aayog viz.(ngodarpan.gov.in), if not done already.</li></ul>
                    </div>
                    
                    <div class="testimonial-word text-center">
                    
                        <h2>4.</h2>
                        <ul><li>Any further Grant-In-Aid would only be released to the NGOs who have furnished the above information correctly in the NITI Aayog NGO-DARPAN Portal (ngodarpan.gov.in).</li></ul>
                    </div>
                    
                    

                    <div class="testimonial-word text-center">
                    
                        <h2>5.</h2>
                        <ul><li>It is mandatory for all NGOs seeking Grant-In-Aid from MoSJE to provide Unique ID (obtained from Niti Aayog NGO-DARPAN Portal) on MoSJE eAnudaan Portal (http://grants-msje.gov.in).</li></ul>
                    </div>

                    

                </div>
            </div>
        </div>
    </section>
    
    
      
       <div class="middle">
      <div style="padding: 40px 0;
      width: 100%;
      background: #fcfcfc">
        <div style="max-width: 1400px;
        margin: auto;
        display: flex;">
        <!-- <div class="row"> -->
          <div style=" flex: 1;
          text-align: center;
          padding: 20px;
          color:#806be8;
          text-transform: uppercase;">
           
            <div class="num" style="color:#806be8;
            font-size: 40px;
            margin: 20px 0;">1246</div>
            Number of registered NGOs
          </div>
  
          <div style=" flex: 1;
          text-align: center;
          padding: 20px;
          color:#806be8;
          text-transform: uppercase;">
            
            <div class="num" style="color:#806be8;
            font-size: 40px;
            margin: 20px 0;">19</div>
            Pending applications
          </div>
  
          <div style=" flex: 1;
          text-align: center;
          padding: 20px;
          color:#806be8;
          text-transform: uppercase;">
           
            <div class="num" style="color:#806be8;
            font-size: 40px;
            margin: 20px 0;">68700000</div>
            Total amount sanctioned
          </div>
  
          <div style=" flex: 1;
          text-align: center;
          padding: 20px;
          color:#806be8;
          text-transform: uppercase;">
           
            <div class="num" style="color:#806be8;
            font-size: 40px;
            margin: 20px 0;">87</div>
            Total NGOs funded
          </div>
          <!-- </div> -->
        </div>
      </div>
    </div>

              
      <div class="container">
        </div>
      
      
      
      
      
      

        <section id="services" class="services-section padding-top-30">
        <div id="fh5co-schedule-section">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2">
						<div class="section-title">
							<h2>Login or Sign Up</h2>
						</div>
					</div>
				</div>
				<div class="row animate-box">
					<div class="row text-center">

						<div class="col-md-12 schedule-container">
								<div class="col-md-6 col-sm-6">
									<div class="program program-schedule">
                    <h3>If not registered yet, Register Here</h3><br>
										
										<h3>REGISTER</h3><br>


                                <button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal">Application Form</button>


                   <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content ">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Fill the Form</h4>
          
        </div>
        <div class="modal-body mm text-center">
                    
            
              <form action="index.php" method="POST">
New Username:<br>
<input type="text" name="firstname">
<br>
New Password:<br>
<input type="text" name="lastname">
<br>
Networth (in lacs):<br>
<input type="text" name="worth">
<br>
Registered followers:<br>
<input type="text" name="followers">
<br>
Victim reach (in k):<br>
<input type="text" name="reach">
<br>
Media rating:<br>
<input type="text" name="rating">
<br>
Staff:<br>
<input type="text" name="staff">
<br>
International Award(s):<br>
<input type="text" name="international">
<br>
National Award(s):<br>
<input type="text" name="national">
<br>
Professional certification:<br>
<input type="text" name="certify">
<br>
Website:<br>
<input type="text" name="web">
<br>
State reach:<br>
<input type="text" name="state">
<br>
Field of Work:<br>
<input type="text" name="work">
<br>
Long for (in years):<br>
<input type="text" name="years">
<br>
International reach:<br>
<input type="text" name="ireach">
<br>
Annual Report:<br>
<input type="text" name="report">
<br>
Recieved grants (in k):<br>
<input type="text" name="grants">
<br><br>
<input type="submit" name="submit">
</form>

                                        
                </div>
           
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

                  </div>
                </div>
								<div class="col-md-6 col-sm-6">
									<div class="program program-schedule">
                    <h3>If already registered, Login Here</h3><br>
										
										<h3>LOGIN</h3><br>


                                 <button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal1">Application Form</button>


                   <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content ">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Fill the Form</h4>
          
        </div>
        <div class="modal-body mm text-center">
                    <form action="index.php" method="POST">
Username:<br>
<input type="text" name="logfirstname">
<br>
Password:<br>
<input type="password" name="loglastname">
<br><br>
<div class="margin-top-10">
                          <input type="submit" name="submit">
</form>

 </div>
           
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

                  </div>
                </div>


							</div>
					</div>
				</div>
			</div>
		</div>
        
    </section>
      
    
     <section id="contact" class="contact-us padding-top-30">
       <div class="container">
          <div class="row">
                <div class="col-sm-12">
                    <div class="section-title">
                        <h2>Contact Us</h2>
                        <p>For any queries, reach us out at</p>
                    </div>
                </div>
            </div>
            
            
           <div class="text-center margin-top-10 margin-bottom-50">
            <div class="row">
            
               <div class="col-md-4 col-sm-4">
                <div class="contact-us-detail">  
                 <i class="fa fa-mobile color-6"></i>
                  <p><a>+91-9101244646</a><br>
                      <a>+91-8876506186</a>
                    </p>
                 </div>
                </div>
               
               <div class="col-md-4 col-sm-4">
                <div class="contact-us-detail">
                 <i class="fa fa-mail-reply color-5"></i>
                  <p><a>team.ngomonitoring@gmail.com</a></p>
                 </div>
                </div>
                 
               <div class="col-md-4 col-sm-4">
                <div class="contact-us-detail">
                 <i class="fa fa-clock-o color-3"></i>
                  <p>Mon - Sat | 09:00 – 20:00</p>
                 </div>
                </div>
              
               </div>
              </div>
         
       </div>
       
      <div class="margin-top-40"> 
       <ul class="social-icon">
         <li><a href="https://www.facebook.com/NITSHacks/?epa=SEARCH_BOX" target="_blank" class="facebook"><i class="fa fa-facebook"></i></a></li>
           <li><a href="https://twitter.com/narendramodi" target="_blank" class="twitter"><i class="fa fa-twitter"></i></a></li>
       </ul>
      </div>
       
     </section>
     <!-- Contact End -->
       
        
        
            <!-- Back to Top Start -->
    <a href="#" class="scroll-to-top"><i class="fa fa-angle-up"></i></a
    <!-- Back to Top End -->
    
    
    

    
    
    <!-- All Javascript Plugins  -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/plugin.js"></script>
    
     <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
    <!-- Main Javascript File  -->
    <script type="text/javascript" src="js/scripts.js"></script>
  
  
  </body>
 </html>